package com.fmr.ATF.JenkinsJob.domain;

import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;

@XmlRootElement(namespace = "com.fmr.ATF.JenkinsJob.domain.JobConfig")
@XmlAccessorType(XmlAccessType.FIELD)
public class Parameter {
	

	 @XmlAttribute
	 private String plugin;
	 @XmlElement
	 private String name;
	 @XmlElement
	 private String description;
	 
	 public String getplugin() {
        return this.plugin;
    }
    public void setPlugin(String plugin) {
        this.plugin = plugin;
    }
    
    public void setName(String name) {
    	this.name = name;
    }
    public String getName() {
    	return this.name;
    }
    
    public void setDes(String description) {
    	this.description = description;
    }
    public String getDed() {
    	return this.description;
    }
}
