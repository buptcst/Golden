package com.fmr.lead.model;

import java.util.ArrayList;
import java.util.List;

public class TestResult {
	public TestResult() {
		this.executionSteps = new ArrayList<String>();
	}
	private String pid;
	private String specName;
	private List<String> executionSteps;
	private String status;
	private String executionTime;
	
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getSpecName() {
		return specName;
	}
	public void setSpecName(String specName) {
		this.specName = specName;
	}
	public List<String> getExecutionSteps() {
		return executionSteps;
	}
	public void setExecutionSteps(List<String> executionSteps) {
		this.executionSteps = executionSteps;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getExecutionTime() {
		return executionTime;
	}
	public void setExecutionTime(String executionTime) {
		this.executionTime = executionTime;
	}
}
