package com.fmr.lead.web;

import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.web.context.support.XmlWebApplicationContext;
/*******************************************************************************
 * 
 *
 * Copyright (c) 2014, 2015, 2016 FMRCO All rights reserved 
 *  Fidelity Internal Information
 *
 * File Name: WebContextInitializer.java
 *
 * Author: ALMaaS Team
 *
 * Date: 30 Jun 2016
 *
 * Description: 
 * Initialize Web context
 *
 *******************************************************************************/
public class WebContextInitializer implements ApplicationContextInitializer<ConfigurableApplicationContext> {
	
	
	
	@Override
    public void initialize(ConfigurableApplicationContext applicationContext) {
		((XmlWebApplicationContext) applicationContext).setConfigLocation("classpath:/spring/mvc-servlet.xml");
    	System.out.println("Web application context initialized.");
    	//applicationContext.refresh();
    }
}
