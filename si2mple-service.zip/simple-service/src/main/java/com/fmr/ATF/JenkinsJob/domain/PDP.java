package com.fmr.ATF.JenkinsJob.domain;

import java.util.ArrayList;

import javax.xml.bind.annotation.*;

@XmlRootElement(namespace = "com.fmr.ATF.JenkinsJob.domain.JobConfig")  
public class PDP {
	@XmlElementWrapper(name = "parameterDefinitions")
	@XmlElement
	private ArrayList<Parameter> parameters;
	
}
