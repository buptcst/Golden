package com.fmr.lead;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Controller
@RequestMapping("/console")
@Api(value = "console", description = "Retrieve the Console Outputs")
public class ConsoleOutputController {
	
	private ConsoleOutputService consoleOutputService;

	@Autowired
	public ConsoleOutputController(ConsoleOutputService consoleOutputService) {
		super();
		this.consoleOutputService = consoleOutputService;
	}


	@RequestMapping(value = "/{buildID}", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	@ApiOperation(value = "Get jenkins console outputs", notes = "Get jenkins console outputs")
	@ApiResponses(value = {
			@ApiResponse(code = 200, response = TestResult[].class, message = "The test result retrieving succeeded"),
			@ApiResponse(code = 400, response = APIError.class, message = "The request parameters were invalid"),
			@ApiResponse(code = 401, response = APIError.class, message = "Unauthorized or invalid API key") })
	@ResponseBody public List<TestResult> getConsoleOutputs(@ApiParam(value = "url", required = true) @PathVariable(value = "buildID") String buildID)
			throws Exception {		
		return consoleOutputService.getTestResults(buildID);
	}

}