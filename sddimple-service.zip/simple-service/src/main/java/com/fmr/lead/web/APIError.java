package com.fmr.lead.web;

import io.swagger.annotations.ApiModelProperty;

/*******************************************************************************
 * 
 *
 * Copyright (c) 2014, 2015, 2016 FMRCO All rights reserved 
 *  Fidelity Internal Information
 *
 * File Name: APIError.java
 *
 * Author: ALMaaS Team
 *
 * Date: 30 Jun 2016
 *
 * Description: 
 * This class is used to indicate errors back through the API
 * in non-200 level responses.
 *
 *******************************************************************************/
public class APIError implements java.io.Serializable {

	private static final long serialVersionUID = -4132232231553684069L;

    @ApiModelProperty(value="The associated request ID", required=true)
	private String requestId;

    @ApiModelProperty(value="The code of error", required=true)
	private String code;

    @ApiModelProperty(value="The message of error", required=true)
	private String message;
    
    @ApiModelProperty(value="The URL containing additional details explaining the error code", required=false)
    private String referenceURL;
    
    /**
     * Creates a new instance of this class.
     */
    public APIError() {
    }
    
    /**
     * Creates a new instance of this class.
     * 
     * @param code
     *        the code associated with this error
     * @param message
     *        the error message
     */
    public APIError(String code, String message) {
        this.code = code;
        this.message = message;
	    referenceURL = "www.fidelity.com";
    }

	/**
     * Gets the error code.
     * 
	 * @return the error code
	 */
	public String getCode() {
		return code;
	}

    /**
     * Sets the error code.
     * 
     * @param code the error code to set
     */
    public void setCode(String code) {
        this.code = code;
    }

	/**
     * Gets the error message.
     * 
	 * @return the error message
	 */
	public String getMessage() {
		return message;
	}
    
    /**
     * Sets the error message.
     * 
     * @param message the error message to set
     */
    public void setMessage(String message) {
        this.message = message;
    }

    /**
     * Gets the URL to the reference documentation about this error
     * 
     * @return the URL to the reference documentation about this error
     */
	public String getReferenceURL() {
        return referenceURL;
	}

    /**
     * Sets the URL to the reference documentation about this error
     * 
     * @param referenceURL the URL to the reference documentation about this error
     */
    public void setReferenceURL(String referenceURL) {
        this.referenceURL = referenceURL;
    }
    
    /**
     * Gets the associated request ID
     * 
     * @return the associated request ID
     */
    public String getRequestId() {
        return requestId;
    }

    /**
     * Sets the associated request ID
     * 
     * @param requestId the associated request ID
     */
    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() {
        return "APIError [requestId=" + requestId + ", code=" + code
                + ", message=" + message + ", referenceURL=" + referenceURL
                + "]";
    }

}
