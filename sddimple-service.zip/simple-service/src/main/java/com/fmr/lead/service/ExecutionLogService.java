package com.fmr.lead.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.fmr.lead.model.LogRecord;

@Service
public class ExecutionLogService {
	
	public List<LogRecord> getExecutionLogs(String buildID) {
		List<LogRecord> list = new ArrayList<LogRecord>();
		LogRecord r = new LogRecord();
		r.setId("1");
		r.setTimestamp("20170111");
		r.setLogContent("What the heck");
		list.add(r);
		return list;
	}

	public void addExecutionLog(LogRecord record) {

	}
}
