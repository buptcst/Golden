package com.fmr.lead.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.fmr.lead.model.LogRecord;
import com.fmr.lead.model.TestResult;
import com.fmr.lead.service.ExecutionLogService;
import com.fmr.lead.web.APIError;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@CrossOrigin(origins = "http://localhost:8080")
@Controller
@RequestMapping("/executionLog")
@Api(value = "executionLog", description = "save or retrieve the execution logs")
public class ExecutionLogController {
	
	private final ExecutionLogService executionLogService;
	
	@Autowired
	public ExecutionLogController(ExecutionLogService executionLogService) {
		super();
		this.executionLogService = executionLogService;
	}
	
	@RequestMapping(value = "/{buildID}", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	@ApiOperation(value = "Get jenkins console outputs", notes = "Get jenkins console outputs")
	@ApiResponses(value = {
			@ApiResponse(code = 200, response = LogRecord[].class, message = "The execution log successufully retrieved"),
			@ApiResponse(code = 400, response = APIError.class, message = "The request parameters were invalid"),
			@ApiResponse(code = 401, response = APIError.class, message = "Unauthorized or invalid API key") })
	@ResponseBody public List<LogRecord> getExecutionLogs(@ApiParam(value = "url", required = true) @PathVariable(value = "buildID") String buildID)
			throws Exception {		
		return executionLogService.getExecutionLogs(buildID);
	}
	
	@RequestMapping(value = "/log", method = RequestMethod.POST, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@ApiOperation(value = "save log to database", notes = "save log to database")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "The execution log successufully saved to database"),
			@ApiResponse(code = 400, response = APIError.class, message = "The request parameters were invalid"),
			@ApiResponse(code = 401, response = APIError.class, message = "Unauthorized or invalid API key") })
	@ResponseBody public void addExecutionLog(@RequestBody LogRecord record)
			throws Exception {		
		executionLogService.addExecutionLog(record);
	}
	


}
