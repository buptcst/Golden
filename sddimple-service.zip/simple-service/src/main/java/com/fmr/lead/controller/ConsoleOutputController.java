package com.fmr.lead.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.ModelAndView;

import com.fmr.lead.model.TestResult;
import com.fmr.lead.model.Users;
import com.fmr.lead.repository.UsersRepository;
import com.fmr.lead.service.ConsoleOutputService;
import com.fmr.lead.web.APIError;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@CrossOrigin(origins = "http://localhost:8080")
@Controller
@RequestMapping("/console")
@Api(value = "console", description = "Retrieve the Console Outputs")
public class ConsoleOutputController {

	private final ConsoleOutputService consoleOutputService;
	private final UsersRepository userRepository;

	@Autowired
	public ConsoleOutputController(ConsoleOutputService consoleOutputService, UsersRepository userRepository) {
		super();
		this.consoleOutputService = consoleOutputService;
		this.userRepository = userRepository;
	}

	@RequestMapping(value = "/{buildID}", method = RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@ApiOperation(value = "Get jenkins console outputs", notes = "Get jenkins console outputs")
	@ApiResponses(value = {
			@ApiResponse(code = 200, response = TestResult[].class, message = "The test result retrieving succeeded"),
			@ApiResponse(code = 400, response = APIError.class, message = "The request parameters were invalid"),
			@ApiResponse(code = 401, response = APIError.class, message = "Unauthorized or invalid API key") })
	@ResponseBody
	public List<TestResult> getConsoleOutputs(
			@ApiParam(value = "url", required = true) @PathVariable(value = "buildID") String buildID)
			throws Exception {
		return consoleOutputService.getTestResults(buildID);
	}

	@RequestMapping(value = "/abc", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	@ApiOperation(value = "abc", notes = "abc")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "The test result retrieving succeeded"),
			@ApiResponse(code = 400, response = APIError.class, message = "The request parameters were invalid"),
			@ApiResponse(code = 401, response = APIError.class, message = "Unauthorized or invalid API key") })
	@ResponseBody
	public void helloWorld() throws Exception {
		userRepository.save(new Users("David", "Lee"));
		userRepository.save(new Users("Saurabh", "Sharma"));
		System.out.println("Customers found with findAll():");
		System.out.println("-------------------------------");
		for (Users users : userRepository.findAll()) {
			System.out.println(users.getFirstName()+""+users.getLastName());
			
		}
		System.out.println();

		// fetch an individual customer
		System.out.println("Customer found with findByFirstName('Alice'):");
		System.out.println("--------------------------------");
		System.out.println(userRepository.findByFirstName("Saurabh").getId());

		System.out.println("Customers found with findByLastName('Smith'):");
		System.out.println("--------------------------------");
		for (Users user : userRepository.findByLastName("Sharma")) {
			System.out.println(user.getId());
		}
	}

}