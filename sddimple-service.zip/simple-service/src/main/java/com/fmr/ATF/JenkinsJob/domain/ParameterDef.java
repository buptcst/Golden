package com.fmr.ATF.JenkinsJob.domain;

public class ParameterDef {

}
