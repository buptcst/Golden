package com.example;
import java.io.File;
import java.io.StringWriter;
import java.util.ArrayList;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import com.fmr.ATF.JenkinsJob.domain.JobConfig;

public class TestJaxb {
	public static void main(String[] args) {

		JobConfig job = new JobConfig();
		 job.setAction("");
		 ArrayList<String> temp=new ArrayList<String>();
		 temp.add("test1");
		 temp.add("test2");
		// job.setParam(temp);
		 //job.setConfigVersion(2);
		  try {

			File file = new File("C:\\file.xml");
			JAXBContext jaxbContext = JAXBContext.newInstance(JobConfig.class);
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

			// output pretty printed
			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			StringWriter sw = new StringWriter();
			jaxbMarshaller.marshal(job, sw);
			System.out.println(sw.toString());

		      } catch (JAXBException e) {
			e.printStackTrace();
		      }

		}
}
