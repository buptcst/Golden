package com.fmr.ATF.JenkinsJob.domain;

import javax.xml.bind.annotation.*;

@XmlRootElement(namespace = "com.fmr.ATF.JenkinsJob.domain.JobConfig")  
public class Properties {
	@XmlElement(name = "hudson.model.ParametersDefinitionProperty")
	private PDP ParametersDefinitionProperty;
	
	public void setPDP(PDP temp) {
		this.ParametersDefinitionProperty = temp;
	}
}
