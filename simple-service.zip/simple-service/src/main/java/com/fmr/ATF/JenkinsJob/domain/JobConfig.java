package com.fmr.ATF.JenkinsJob.domain;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "project")
public class JobConfig {
	@XmlElement
	private String actions;
	@XmlElement
	private String description;
	@XmlElement
	private boolean keepDependencies;
	
	@XmlElement
	private Properties properties;
	
	public void setAction(String actions) {
		this.actions = actions;
	}
	
	public void setDescription(String des) {
		this.description = des;
	}
	public void setParam(Properties properties) {
		this.properties = properties;
	}
	public void setKeepDependencies(boolean keep) {
		this.keepDependencies = keep;
	}
	
}
